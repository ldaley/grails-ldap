package grails.ldap;
import org.codehaus.groovy.grails.commons.AbstractGrailsClass;

public class DefaultGrailsLdapClass extends AbstractGrailsClass implements GrailsLdapClass {
    
    public DefaultGrailsLdapClass(Class clazz) {
        super(clazz, "");
    }

}