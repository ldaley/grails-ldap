package grails.ldap;

import org.codehaus.groovy.grails.commons.GrailsClass;

public interface GrailsLdapClass extends GrailsClass {
    
}